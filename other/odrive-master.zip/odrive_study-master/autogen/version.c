const unsigned char fw_version_major_ = 0;
const unsigned char fw_version_minor_ = 5;
const unsigned char fw_version_revision_ = 6;
const unsigned char fw_version_unreleased_ = 1;
