#ifndef __PWM_ADC_H
#define __PWM_ADC_H

#include "config.h"

void Start_Get_Image(void);
void PWM_ADC_Init(void);
extern bit ADC_Finish; // �ɹ���1

#endif